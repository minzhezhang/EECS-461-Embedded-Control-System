/*
 * File: freemaster_device.h
 *
 * Code generated for Simulink model 'template_Final_Project_MPC5643L'.
 *
 * Model version                  : 1.255
 * Simulink Coder version         : 8.1 (R2011b) 08-Jul-2011
 * TLC version                    : 8.1 (Jul  9 2011)
 * C/C++ source code generated on : Thu Apr 14 16:42:02 2016
 *
 * Target selection: rappid564xl.tlc
 * Embedded hardware selection: Motorola PowerPC
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_freemaster_device_h_
#define RTW_HEADER_freemaster_device_h_
#endif                                 /* RTW_HEADER_freemaster_device_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
