/*
 * File: template_Final_Project_MPC5643L_data.c
 *
 * Code generated for Simulink model 'template_Final_Project_MPC5643L'.
 *
 * Model version                  : 1.255
 * Simulink Coder version         : 8.1 (R2011b) 08-Jul-2011
 * TLC version                    : 8.1 (Jul  9 2011)
 * C/C++ source code generated on : Thu Apr 14 16:42:02 2016
 *
 * Target selection: rappid564xl.tlc
 * Embedded hardware selection: Motorola PowerPC
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "template_Final_Project_MPC5643L.h"
#include "template_Final_Project_MPC5643L_private.h"

/* Constant parameters (auto storage) */
const ConstParam_template_Final_Proje template_Final_Project_M_ConstP = {
  /* Computed Parameter: Constant_Value
   * Referenced by: '<S5>/Constant'
   */
  10.0F
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
