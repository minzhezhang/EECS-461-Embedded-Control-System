/*
 * File: template_Final_Project_MPC5643L_private.h
 *
 * Code generated for Simulink model 'template_Final_Project_MPC5643L'.
 *
 * Model version                  : 1.255
 * Simulink Coder version         : 8.1 (R2011b) 08-Jul-2011
 * TLC version                    : 8.1 (Jul  9 2011)
 * C/C++ source code generated on : Thu Apr 14 16:42:02 2016
 *
 * Target selection: rappid564xl.tlc
 * Embedded hardware selection: Motorola PowerPC
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_template_Final_Project_MPC5643L_private_h_
#define RTW_HEADER_template_Final_Project_MPC5643L_private_h_
#include "rtwtypes.h"
#include "MPC5643L.h"
#include "flexcan_564xl_library.h"
#include "gpio_564xl_library.h"
#include "adc_564xl_library.h"
#include "path_data.h"
#include "path_data.h"
#include "FlexPWM_564xL_library.h"
#include "flexpwm_init.h"
#include "adc0_config.h"
#include "eTimer_564xL_library.h"
#ifndef __RTWTYPES_H__
#error This file requires rtwtypes.h to be included
#else
#ifdef TMWTYPES_PREVIOUSLY_INCLUDED
#error This file requires rtwtypes.h to be included before tmwtypes.h
#else

/* Check for inclusion of an incorrect version of rtwtypes.h */
#ifndef RTWTYPES_ID_C08S16I32L32N32F1
#error This code was generated with a different "rtwtypes.h" than the file included
#endif                                 /* RTWTYPES_ID_C08S16I32L32N32F1 */
#endif                                 /* TMWTYPES_PREVIOUSLY_INCLUDED */
#endif                                 /* __RTWTYPES_H__ */

extern void vehicle_model_Outputs_wrapper(const real32_T *u,
  const real32_T *psi,
  const real32_T *delta,
  real32_T *dotx,
  real32_T *doty,
  real32_T *dotpsi);
extern void ACC_Logic_Outputs_wrapper(const boolean_T *en_man,
  const real32_T *s,
  const real32_T *u,
  const real32_T *H,
  boolean_T *en_vel,
  boolean_T *en_pos,
  real32_T *lead_s,
  real32_T *lead_us);
extern void us_calc_Outputs_wrapper(const real32_T *delta,
  const real32_T *psi,
  const real32_T *fx,
  const real32_T *fy,
  const real32_T *u,
  real32_T *us);
extern void SerialInit_Outputs_wrapper();
extern void template_Final_Project_MPC5643L_step0(void);
extern void template_Final_Project_MPC5643L_step1(void);

#endif                                 /* RTW_HEADER_template_Final_Project_MPC5643L_private_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
