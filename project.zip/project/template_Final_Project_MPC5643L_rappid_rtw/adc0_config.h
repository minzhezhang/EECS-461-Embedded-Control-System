#include "template_Final_Project_MPC5643L.h"
#include "template_Final_Project_MPC5643L_private.h"

extern void adc0_config(void);
